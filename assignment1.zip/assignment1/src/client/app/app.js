// Name: Balamurugan Santhosam
// Course: INFT 2202
// Date: 2024-03-16


// Set the current year in the footer
document.getElementById('copyrightYear').textContent = new Date().getFullYear();